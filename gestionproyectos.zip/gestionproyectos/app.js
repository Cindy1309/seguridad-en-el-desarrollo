const API_URL = 'http://localhost:3000/api/proyectos';
const listaProyectos = document.getElementById('listaProyectos');
const sinProyectos = document.getElementById('sinProyectos');
const formProyecto = document.getElementById('formProyecto');

// Cargar proyectos al inicio
window.onload = cargarProyectos;

// Configurar fecha mínima (hoy)
document.getElementById('fecha').min = new Date().toISOString().split('T')[0];

// Manejar formulario
formProyecto.addEventListener('submit', guardarProyecto);

// Función para cargar proyectos
async function cargarProyectos() {
    try {
        const response = await fetch(API_URL);
        const proyectos = await response.json();
        mostrarProyectos(proyectos);
    } catch (error) {
        console.error('Error:', error);
        alert('Error al cargar proyectos');
    }
}

// Función para mostrar proyectos en el HTML
function mostrarProyectos(proyectos) {
    listaProyectos.innerHTML = '';

    if (proyectos.length === 0) {
        sinProyectos.style.display = 'block';
        return;
    }

    sinProyectos.style.display = 'none';

    proyectos.forEach(proyecto => {
        const clasePrioridad = proyecto.prioridad;
        const fechaFormateada = new Date(proyecto.fecha).toLocaleDateString('es-ES');

        const proyectoHTML = `
            <div class="card ${clasePrioridad}">
                <div class="card-body">
                    <h5 class="card-title">${proyecto.nombre}</h5>
                    <p class="card-text">${proyecto.descripcion || 'Sin descripción'}</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="badge bg-secondary">${proyecto.prioridad}</span>
                        <small class="text-muted">${fechaFormateada}</small>
                    </div>
                </div>
            </div>
        `;

        listaProyectos.innerHTML += proyectoHTML;
    });
}

// Función para enviar y guardar un nuevo proyecto
async function guardarProyecto(event) {
    event.preventDefault();

    const proyecto = {
        nombre: document.getElementById('nombre').value,
        descripcion: document.getElementById('descripcion').value,
        fecha: document.getElementById('fecha').value,
        prioridad: document.getElementById('prioridad').value
    };

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(proyecto)
        });

        if (!response.ok) {
            throw new Error('Error al guardar');
        }

        alert('Proyecto creado');

        // Cerrar modal y limpiar formulario
        const modalElement = document.getElementById('modalProyecto');
        const modal = bootstrap.Modal.getInstance(modalElement);
        modal.hide();
        formProyecto.reset();

        // Recargar la lista automáticamente
        cargarProyectos();

    } catch (error) {
        console.error('Error:', error);
        alert('Error al guardar proyecto');
    }
}